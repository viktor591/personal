import * as React from "react";
export function Separator() {
  return <hr className="border-gray-200 my-2" />;
}
