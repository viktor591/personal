# Eleven Founder Score — Password Protected

**How to log in:** any password that starts with `11VC_` (example: `11VC_test`). Username can be anything.

## Run locally
```bash
npm i
npm run dev
```
Open http://localhost:3000 (your browser will ask for username/password).

## Deploy to Vercel
1. Push this folder to a new GitHub repository (GitHub → New → **Create** → then **Add files** → **Upload files** and drag the whole folder).
2. Go to Vercel → **Add New...** → **Project** → Import the GitHub repo → accept defaults → **Deploy**.
3. Visit your URL and enter a password that starts with `11VC_`.
